# Everyday Nutrition — Android Studio project

This is a starter Android app project that packages the current Everyday Nutrition tracker inside an Android WebView. It includes the tracker HTML locally, so the main tracker interface can open without an internet connection.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`EverydayNutrition`) in Android Studio.
3. Let Gradle sync. If prompted, install Android SDK Platform 35 and a compatible JDK.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build succeeds, use Android Studio's notification link to locate the APK. It is normally under `app/build/outputs/apk/debug/`.
6. Transfer the APK to your Android phone and open it to install. Android may ask you to allow installs from that source.

## Important
- This is a buildable project source, not a precompiled APK. It must be built with Android Studio/Android SDK.
- This is a first prototype using a WebView; it is not yet published on Google Play.
- App data is stored by the local browser storage inside the app on that device. Uninstalling the app or clearing its data may erase records. Export backups regularly.
- The calorie and activity calculations are estimates, not medical advice.
